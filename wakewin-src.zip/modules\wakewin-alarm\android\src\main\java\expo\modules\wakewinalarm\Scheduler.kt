package expo.modules.wakewinalarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import java.util.Calendar

object Scheduler {
  private fun mgr(c: Context) = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

  private fun firePi(c: Context, kind: String, id: String): PendingIntent {
    val i = Intent(c, AlarmReceiver::class.java).putExtra("kind", kind).putExtra("id", id)
    return PendingIntent.getBroadcast(
      c, ("$kind:$id").hashCode(), i,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
  }

  private fun showPi(c: Context): PendingIntent {
    val launch = c.packageManager.getLaunchIntentForPackage(c.packageName)
    return PendingIntent.getActivity(
      c, 1, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
  }

  private fun set(c: Context, kind: String, id: String, at: Long) {
    // setAlarmClock = same API the system clock app uses: exact, works in Doze, needs no extra permission
    mgr(c).setAlarmClock(AlarmManager.AlarmClockInfo(at, showPi(c)), firePi(c, kind, id))
  }

  private fun cancel(c: Context, kind: String, id: String) {
    mgr(c).cancel(firePi(c, kind, id))
  }

  /** Next time (millis) this alarm should ring, or -1. Days: index 0 = Sunday. */
  fun nextTrigger(hour: Int, minute: Int, days: JSONArray?): Long {
    val now = System.currentTimeMillis()
    val anyDay = days != null && (0 until days.length()).any { days.optBoolean(it) }
    for (add in 0..7) {
      val c = Calendar.getInstance()
      c.add(Calendar.DAY_OF_YEAR, add)
      c.set(Calendar.HOUR_OF_DAY, hour)
      c.set(Calendar.MINUTE, minute)
      c.set(Calendar.SECOND, 0)
      c.set(Calendar.MILLISECOND, 0)
      if (c.timeInMillis <= now) continue
      val dow = c.get(Calendar.DAY_OF_WEEK) - 1
      if (!anyDay || days!!.optBoolean(dow)) return c.timeInMillis
    }
    return -1
  }

  fun scheduleAll(c: Context) {
    Store.scheduledIds(c).forEach { cancel(c, "alarm", it) }
    val arr = Store.alarms(c)
    val ids = mutableSetOf<String>()
    for (i in 0 until arr.length()) {
      val a = arr.getJSONObject(i)
      if (!a.optBoolean("on")) continue
      val id = a.getString("id")
      val at = nextTrigger(a.getInt("hour"), a.getInt("minute"), a.optJSONArray("days"))
      if (at > 0) {
        set(c, "alarm", id, at)
        ids.add(id)
      }
    }
    Store.saveScheduledIds(c, ids)
  }

  /** Called right after an alarm rings: set the next repeat, or switch a one-time alarm off. */
  fun afterFire(c: Context, id: String) {
    val a = Store.findAlarm(c, id) ?: return
    val days = a.optJSONArray("days")
    val repeats = days != null && (0 until days.length()).any { days.optBoolean(it) }
    if (repeats) {
      val at = nextTrigger(a.getInt("hour"), a.getInt("minute"), days)
      if (at > 0) set(c, "alarm", id, at)
    } else {
      Store.setAlarmOff(c, id)
    }
  }

  fun scheduleTimer(c: Context, id: String, endAt: Long, label: String) {
    if (endAt <= System.currentTimeMillis()) return
    Store.putTimer(c, id, endAt, label)
    set(c, "timer", id, endAt)
  }

  fun cancelTimer(c: Context, id: String) {
    Store.removeTimer(c, id)
    cancel(c, "timer", id)
  }

  fun restoreAfterBoot(c: Context) {
    scheduleAll(c)
    val t = Store.timers(c)
    val now = System.currentTimeMillis()
    val keys = t.keys()
    while (keys.hasNext()) {
      val id = keys.next()
      val endAt = t.getJSONObject(id).optLong("endAt")
      if (endAt > now) set(c, "timer", id, endAt) else Store.removeTimer(c, id)
    }
  }
}
