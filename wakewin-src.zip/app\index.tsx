import { useState, useEffect, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Switch, Vibration, Modal, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import * as Haptics from 'expo-haptics';
import { useAudioPlayer, setAudioModeAsync } from 'expo-audio';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as DocumentPicker from 'expo-document-picker';
import * as WW from '../modules/wakewin-alarm';

type Mission = 'None' | 'Phrase' | 'Math';
type SoundKind = 'default' | 'vibrate' | 'custom';
type Alarm = {
  id: string;
  hour: number;
  minute: number;
  label: string;
  days: boolean[];
  mission: Mission;
  sound: SoundKind;
  soundUri?: string;
  soundName?: string;
  on: boolean;
};
type Timer = { id: string; label: string; total: number; left: number; endAt: number | null };
type Ring = { title: string; sub: string; mission: Mission; sound: SoundKind; uri?: string };

const ORANGE = '#FF5722';
const PHRASE = 'I will work and I will win';
const DEFAULT_SOUND = require('./assets/alarm.mp3');
const QUOTES = [
  'Discipline is choosing what you want most over what you want now.',
  'Win the morning, win the day.',
  'Small steps every day beat big plans someday.',
  'Your future self is watching. Make them proud.',
];
const DAY_ORDER = [1, 2, 3, 4, 5, 6, 0];
const DAY_LETTERS = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const WEEKDAYS = [false, true, true, true, true, true, false];
const ALL_DAYS = [true, true, true, true, true, true, true];
const SAMPLE: Alarm[] = [
  { id: '1', hour: 5, minute: 0, label: 'Gym', days: WEEKDAYS, mission: 'Phrase', sound: 'default', on: true },
  { id: '2', hour: 19, minute: 0, label: 'Study', days: ALL_DAYS, mission: 'Math', sound: 'default', on: true },
];

const fmt = (h: number, m: number) => {
  const ap = h >= 12 ? 'PM' : 'AM';
  const hh = h % 12 === 0 ? 12 : h % 12;
  return `${hh}:${String(m).padStart(2, '0')} ${ap}`;
};

const fmtDur = (sec: number) => {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const p = (n: number) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${p(m)}:${p(s)}` : `${p(m)}:${p(s)}`;
};

const daysText = (d: boolean[]) => {
  if (d.every(Boolean)) return 'Daily';
  if (!d.some(Boolean)) return 'Once';
  if (d.join() === WEEKDAYS.join()) return 'Mon–Fri';
  return DAY_ORDER.filter(i => d[i]).map(i => DAY_NAMES[i]).join(' ');
};

const minutesUntil = (a: Alarm, now: Date) => {
  for (let add = 0; add <= 7; add++) {
    const d = new Date(now);
    d.setDate(now.getDate() + add);
    d.setHours(a.hour, a.minute, 0, 0);
    if (d.getTime() <= now.getTime()) continue;
    if (!a.days.some(Boolean) || a.days[d.getDay()]) {
      return Math.round((d.getTime() - now.getTime()) / 60000);
    }
  }
  return null;
};

const parseTime = (l: string) => {
  const m =
    l.match(/(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)/) ||
    l.match(/(?:at|for)\s+(\d{1,2})(?::(\d{2}))?()/) ||
    l.match(/(\d{1,2}):(\d{2})()/);
  if (!m) return null;
  let h = parseInt(m[1], 10);
  const min = m[2] ? parseInt(m[2], 10) : 0;
  const ap = m[3] ? m[3][0] : '';
  if (ap === 'p' && h < 12) h += 12;
  if (ap === 'a' && h === 12) h = 0;
  if (h > 23 || min > 59) return null;
  return { hour: h, minute: min };
};

const parseDuration = (l: string) => {
  const grab = (re: RegExp) => {
    const x = l.match(re);
    return x ? parseInt(x[1], 10) : 0;
  };
  const h = grab(/(\d+)\s*(?:hours?|hrs?|h)\b/);
  const m = grab(/(\d+)\s*(?:minutes?|mins?|m)\b/);
  const s = grab(/(\d+)\s*(?:seconds?|secs?|s)\b/);
  return h * 3600 + m * 60 + s;
};

const parseCommand = (text: string): any => {
  const l = text.toLowerCase().trim();
  if (!l) return { kind: null };
  const labelMatch = text.match(/(?:called|named|labell?ed|label)\s+([\w ]+?)(?=\s+(?:with|on|at|every|daily|for|and)\b|$)/i);
  const label = labelMatch ? labelMatch[1].trim() : '';
  const dur = parseDuration(l);
  const hasAmPm = /\d\s*(am|pm|a\.m\.|p\.m\.)/.test(l);
  const isTimer = /\b(timer|countdown)\b/.test(l) || (dur > 0 && !hasAmPm && !/\b(at|alarm|wake)\b/.test(l));
  if (isTimer && dur > 0) return { kind: 'timer', total: dur, label };

  const time = parseTime(l);
  let days: boolean[] | null = null;
  if (/\b(daily|every ?day|everyday)\b/.test(l)) days = ALL_DAYS;
  else if (/\bweekdays?\b/.test(l)) days = WEEKDAYS;
  else if (/\bweekends?\b/.test(l)) days = [true, false, false, false, false, false, true];
  else {
    const names = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
    const d = names.map(n => new RegExp('\\b' + n).test(l));
    if (d.some(Boolean)) days = d;
  }
  let mission: Mission | null = null;
  if (/\b(math|maths|sum|sums|calculation)\b/.test(l)) mission = 'Math';
  else if (/\b(phrase|typing|type)\b/.test(l)) mission = 'Phrase';
  else if (/\b(no mission|no task|simple)\b/.test(l)) mission = 'None';

  if (!time && !days && !mission && !label) return { kind: null };
  return { kind: 'alarm', time, days, mission, label };
};

export default function Home() {
  const [now, setNow] = useState(new Date());
  const [tab, setTab] = useState<'home' | 'alarms' | 'timers'>('home');
  const [alarms, setAlarms] = useState<Alarm[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [timers, setTimers] = useState<Timer[]>([]);

  const [editor, setEditor] = useState<null | { mode: 'voice' | 'manual'; id: string | null }>(null);
  const [hour, setHour] = useState(7);
  const [minute, setMinute] = useState(0);
  const [hStr, setHStr] = useState('7');
  const [mStr, setMStr] = useState('00');
  const [label, setLabel] = useState('Alarm');
  const [days, setDays] = useState<boolean[]>(WEEKDAYS);
  const [mission, setMission] = useState<Mission>('Phrase');
  const [sound, setSound] = useState<SoundKind>('default');
  const [soundUri, setSoundUri] = useState<string | undefined>();
  const [soundName, setSoundName] = useState<string | undefined>();
  const [cmd, setCmd] = useState('');

  const [tMin, setTMin] = useState('5');
  const [tSec, setTSec] = useState('0');
  const [tLabel, setTLabel] = useState('');

  const [ring, setRing] = useState<Ring | null>(null);
  const [typed, setTyped] = useState('');
  const [q, setQ] = useState({ a: 40, b: 12, op: '+' });
  const fired = useRef<Set<string>>(new Set());
  const player = useAudioPlayer(null);

  const isPM = hour >= 12;

  const applyTime = (h: number, m: number) => {
    setHour(h);
    setMinute(m);
    setHStr(String(h % 12 || 12));
    setMStr(String(m).padStart(2, '0'));
  };

  const onHour = (t: string) => {
    const clean = t.replace(/[^0-9]/g, '').slice(0, 2);
    setHStr(clean);
    const n = parseInt(clean, 10);
    if (!isNaN(n) && n >= 1 && n <= 12) setHour((n % 12) + (isPM ? 12 : 0));
  };

  const onMinute = (t: string) => {
    const clean = t.replace(/[^0-9]/g, '').slice(0, 2);
    setMStr(clean);
    const n = parseInt(clean, 10);
    if (!isNaN(n) && n >= 0 && n <= 59) setMinute(n);
  };

  const setAmPm = (pm: boolean) => setHour((hour % 12) + (pm ? 12 : 0));

  // load + save alarms
  useEffect(() => {
    AsyncStorage.getItem('alarms')
      .then(v => {
        if (v) {
          try {
            const arr = JSON.parse(v);
            setAlarms(arr.map((a: any) => ({ sound: 'default', ...a })));
          } catch {
            setAlarms(SAMPLE);
          }
        } else {
          setAlarms(SAMPLE);
        }
        setLoaded(true);
      })
      .catch(() => {
        setAlarms(SAMPLE);
        setLoaded(true);
      });
  }, []);

  useEffect(() => {
    if (loaded) AsyncStorage.setItem('alarms', JSON.stringify(alarms));
  }, [alarms, loaded]);

  useEffect(() => {
    if (loaded) WW.syncAlarms(alarms);
  }, [alarms, loaded]);

  useEffect(() => {
    WW.runSetupOnce();
  }, []);

  // clock tick
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const startRing = (r: Ring) => {
    const op = Math.random() < 0.5 ? '+' : '-';
    setQ({ a: Math.floor(Math.random() * 70) + 30, b: Math.floor(Math.random() * 15) + 10, op });
    setTyped('');
    setRing(r);
  };

  // pick up alarms/timers that the Android system rang
  useEffect(() => {
    if (ring || !loaded) return;
    const active = WW.getActiveAlarm();
    if (!active) return;
    if (active.kind === 'timer') {
      const t = timers.find(x => x.id === active.id);
      setTimers(prev => prev.map(x => (x.id === active.id ? { ...x, endAt: null, left: 0 } : x)));
      startRing({ title: (t && t.label) || 'Timer', sub: "Time's up!", mission: 'None', sound: 'vibrate' });
    } else {
      const a = alarms.find(x => x.id === active.id);
      if (!a) {
        WW.stopAlarm();
        return;
      }
      if (!a.days.some(Boolean)) {
        setAlarms(prev => prev.map(x => (x.id === a.id ? { ...x, on: false } : x)));
      }
      startRing({ title: a.label, sub: fmt(a.hour, a.minute), mission: a.mission, sound: 'vibrate' });
    }
  }, [now]);

  // sound + vibration while ringing
  useEffect(() => {
    if (!ring) return;
    setAudioModeAsync({ playsInSilentMode: true });
    if (ring.sound !== 'vibrate') {
      try {
        player.replace(ring.sound === 'custom' && ring.uri ? { uri: ring.uri } : DEFAULT_SOUND);
        player.loop = true;
        player.play();
      } catch (e) {}
    }
    Vibration.vibrate([0, 800, 400], true);
    const id = setInterval(() => {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    }, 1200);
    return () => {
      clearInterval(id);
      Vibration.cancel();
      try {
        player.pause();
      } catch (e) {}
    };
  }, [ring]);

  const resetFields = () => {
    applyTime(7, 0);
    setLabel('Alarm');
    setDays(WEEKDAYS);
    setMission('Phrase');
    setSound('default');
    setSoundUri(undefined);
    setSoundName(undefined);
    setCmd('');
  };

  const openVoice = () => {
    resetFields();
    setEditor({ mode: 'voice', id: null });
  };

  const openManual = () => {
    resetFields();
    setEditor({ mode: 'manual', id: null });
  };

  const openEdit = (a: Alarm) => {
    applyTime(a.hour, a.minute);
    setLabel(a.label);
    setDays(a.days);
    setMission(a.mission);
    setSound(a.sound);
    setSoundUri(a.soundUri);
    setSoundName(a.soundName);
    setCmd('');
    setEditor({ mode: 'manual', id: a.id });
  };

  const onCmd = (text: string) => {
    setCmd(text);
    const p = parseCommand(text);
    if (p.kind === 'alarm') {
      if (p.time) applyTime(p.time.hour, p.time.minute);
      if (p.days) setDays(p.days);
      if (p.mission) setMission(p.mission);
      if (p.label) setLabel(p.label.charAt(0).toUpperCase() + p.label.slice(1));
    }
  };

  const pc = editor && editor.mode === 'voice' ? parseCommand(cmd) : null;
  const isTimerCmd = !!pc && pc.kind === 'timer';

  const pickAudio = async () => {
    try {
      const r = await DocumentPicker.getDocumentAsync({ type: 'audio/*', copyToCacheDirectory: true });
      if (!r.canceled && r.assets && r.assets.length) {
        setSoundUri(r.assets[0].uri);
        setSoundName(r.assets[0].name);
        setSound('custom');
      }
    } catch (e) {}
  };

  const addTimer = (total: number, name: string) => {
    const id = Date.now().toString();
    const endAt = Date.now() + total * 1000;
    setTimers(prev => [...prev, { id, label: name, total, left: total, endAt }]);
    WW.scheduleTimer(id, endAt, name);
  };

  const accept = () => {
    if (pc && pc.kind === 'timer') {
      addTimer(pc.total, pc.label || '');
      setEditor(null);
      setTab('timers');
      return;
    }
    const base = { hour, minute, label: label.trim() || 'Alarm', days, mission, sound, soundUri, soundName };
    if (editor && editor.id) {
      setAlarms(alarms.map(a => (a.id === editor.id ? { ...a, ...base, on: true } : a)));
    } else {
      setAlarms([...alarms, { id: Date.now().toString(), ...base, on: true }]);
    }
    setEditor(null);
  };

  const deleteAlarm = () => {
    if (editor && editor.id) setAlarms(alarms.filter(a => a.id !== editor.id));
    setEditor(null);
  };

  const toggle = (id: string) => setAlarms(alarms.map(a => (a.id === id ? { ...a, on: !a.on } : a)));

  const remaining = (t: Timer) => (t.endAt ? Math.max(0, Math.ceil((t.endAt - now.getTime()) / 1000)) : t.left);

  const toggleTimer = (t: Timer) => {
    if (t.endAt) {
      WW.cancelTimer(t.id);
      setTimers(timers.map(x => (x.id === t.id ? { ...x, left: remaining(x), endAt: null } : x)));
    } else {
      const left = t.left > 0 ? t.left : t.total;
      const endAt = Date.now() + left * 1000;
      WW.scheduleTimer(t.id, endAt, t.label);
      setTimers(timers.map(x => (x.id === t.id ? { ...x, left, endAt } : x)));
    }
  };

  const resetTimer = (t: Timer) => {
    WW.cancelTimer(t.id);
    setTimers(timers.map(x => (x.id === t.id ? { ...x, endAt: null, left: x.total } : x)));
  };
  const deleteTimer = (t: Timer) => {
    WW.cancelTimer(t.id);
    setTimers(timers.filter(x => x.id !== t.id));
  };

  const startTimerFromForm = () => {
    const total = (parseInt(tMin, 10) || 0) * 60 + (parseInt(tSec, 10) || 0);
    if (total <= 0) return;
    addTimer(total, tLabel.trim());
    setTLabel('');
  };

  const answer = q.op === '+' ? q.a + q.b : q.a - q.b;
  const solved = !ring
    ? false
    : ring.mission === 'None'
    ? true
    : ring.mission === 'Math'
    ? typed.trim() === String(answer)
    : typed.trim().toLowerCase() === PHRASE.toLowerCase();

  const stopRing = () => {
    if (!solved) return;
    WW.stopAlarm();
    setRing(null);
    setTyped('');
  };

  const sorted = [...alarms].sort((a, b) => a.hour * 60 + a.minute - (b.hour * 60 + b.minute));
  const mins = alarms
    .filter(a => a.on)
    .map(a => minutesUntil(a, now))
    .filter((m): m is number => m !== null);
  const next = mins.length ? Math.min(...mins) : null;
  const nextText =
    next === null ? 'No alarms on' : `Next alarm in ${next >= 60 ? Math.floor(next / 60) + 'h ' : ''}${next % 60}m`;
  const h12 = now.getHours() % 12 || 12;
  const clock = `${h12}:${String(now.getMinutes()).padStart(2, '0')}`;
  const quote = QUOTES[now.getDate() % QUOTES.length];

  if (ring) {
    return (
      <View style={s.ringContainer}>
        <Text style={s.ringTime}>{ring.sub}</Text>
        <Text style={s.ringTitle}>{ring.title}</Text>
        {ring.mission === 'Math' && (
          <>
            <Text style={s.ringHint}>Solve this to stop the alarm:</Text>
            <Text style={s.phrase}>
              {q.a} {q.op} {q.b} = ?
            </Text>
          </>
        )}
        {ring.mission === 'Phrase' && (
          <>
            <Text style={s.ringHint}>Type this phrase to stop the alarm:</Text>
            <Text style={s.phrase}>{PHRASE}</Text>
          </>
        )}
        {ring.mission !== 'None' && (
          <TextInput
            style={s.input2}
            placeholder="Type here"
            placeholderTextColor="#888"
            value={typed}
            onChangeText={setTyped}
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType={ring.mission === 'Math' ? 'numeric' : 'default'}
          />
        )}
        <TouchableOpacity style={[s.primaryBtn, !solved && { opacity: 0.3 }]} onPress={stopRing} disabled={!solved}>
          <Text style={s.primaryText}>Stop</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const renderAlarm = (a: Alarm) => {
    const bits = [
      a.label,
      daysText(a.days),
      a.mission === 'None' ? 'No mission' : a.mission,
      a.sound === 'custom' ? '♪ ' + (a.soundName || 'My audio') : a.sound === 'vibrate' ? 'Vibrate' : '',
    ].filter(Boolean);
    return (
      <View key={a.id} style={s.card}>
        <TouchableOpacity style={{ flex: 1 }} onPress={() => openEdit(a)}>
          <Text style={s.cardTime}>{fmt(a.hour, a.minute)}</Text>
          <Text style={s.cardSub}>{bits.join(' • ')}</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={s.testBtn}
          onPress={() =>
            startRing({ title: a.label, sub: fmt(a.hour, a.minute), mission: a.mission, sound: a.sound, uri: a.soundUri })
          }
        >
          <Text style={s.testText}>Test</Text>
        </TouchableOpacity>
        <Switch value={a.on} onValueChange={() => toggle(a.id)} trackColor={{ true: ORANGE }} />
      </View>
    );
  };

  return (
    <View style={s.container}>
      <View style={s.header}>
        <Text style={s.title}>WakeWin</Text>
        <Ionicons name="settings-outline" size={24} color="#ddd" />
      </View>

      {tab === 'home' && (
        <ScrollView contentContainerStyle={{ paddingBottom: 20 }}>
          <Text style={s.clock}>{clock}</Text>
          <View style={s.pill}>
            <Ionicons name="alarm-outline" size={20} color={ORANGE} />
            <Text style={s.pillText}>{nextText}</Text>
          </View>
          <Text style={s.quote}>“{quote}”</Text>
          <View style={s.rowBetween}>
            <Text style={s.section}>Your alarms</Text>
            <TouchableOpacity onPress={() => setTab('alarms')}>
              <Text style={s.seeAll}>See all</Text>
            </TouchableOpacity>
          </View>
          {sorted.slice(0, 2).map(renderAlarm)}
          <View style={{ alignItems: 'center', marginTop: 16 }}>
            <TouchableOpacity style={s.mic} onPress={openVoice}>
              <Ionicons name="mic" size={36} color="#fff" />
            </TouchableOpacity>
            <Text style={s.micHint}>Tap and say “Wake me up at 5 AM”</Text>
            <TouchableOpacity style={s.manualBtn} onPress={openManual}>
              <Ionicons name="create-outline" size={18} color={ORANGE} />
              <Text style={s.manualText}>Set manually</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      )}

      {tab === 'alarms' && (
        <ScrollView contentContainerStyle={{ paddingBottom: 20 }}>
          <Text style={[s.section, { marginVertical: 12 }]}>All alarms</Text>
          {sorted.map(renderAlarm)}
          <View style={{ flexDirection: 'row', marginTop: 10 }}>
            <TouchableOpacity style={[s.primaryBtn, { flex: 1, marginRight: 8 }]} onPress={openManual}>
              <Text style={s.primaryText}>+ Manual</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[s.outlineBtn, { flex: 1, marginTop: 0, marginBottom: 0 }]} onPress={openVoice}>
              <Text style={{ color: '#fff', fontSize: 16 }}>🎤 Voice</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      )}

      {tab === 'timers' && (
        <ScrollView contentContainerStyle={{ paddingBottom: 20 }} keyboardShouldPersistTaps="handled">
          <Text style={[s.section, { marginVertical: 12 }]}>New timer</Text>
          <View style={s.box}>
            <View style={s.timerInputs}>
              <TextInput style={s.timeBox} value={tMin} onChangeText={setTMin} keyboardType="numeric" maxLength={3} />
              <Text style={s.timeUnit}>min</Text>
              <TextInput style={s.timeBox} value={tSec} onChangeText={setTSec} keyboardType="numeric" maxLength={2} />
              <Text style={s.timeUnit}>sec</Text>
            </View>
            <View style={s.chipsRow}>
              {[1, 5, 10, 15, 30].map(n => (
                <TouchableOpacity
                  key={n}
                  style={s.missionChip}
                  onPress={() => {
                    setTMin(String(n));
                    setTSec('0');
                  }}
                >
                  <Text style={{ color: '#fff' }}>{n}m</Text>
                </TouchableOpacity>
              ))}
            </View>
            <TextInput
              style={s.labelInput}
              value={tLabel}
              onChangeText={setTLabel}
              placeholder="Label (optional)"
              placeholderTextColor="#888"
            />
            <TouchableOpacity style={[s.primaryBtn, { marginTop: 12 }]} onPress={startTimerFromForm}>
              <Text style={s.primaryText}>Start timer</Text>
            </TouchableOpacity>
          </View>
          {timers.map(t => (
            <View key={t.id} style={s.card}>
              <View style={{ flex: 1 }}>
                <Text style={s.cardTime}>{fmtDur(remaining(t))}</Text>
                <Text style={s.cardSub}>
                  {t.label || 'Timer'} • {fmtDur(t.total)}
                </Text>
              </View>
              <TouchableOpacity onPress={() => toggleTimer(t)} style={s.iconBtn}>
                <Ionicons name={t.endAt ? 'pause' : 'play'} size={22} color={ORANGE} />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => resetTimer(t)} style={s.iconBtn}>
                <Ionicons name="refresh" size={22} color="#bbb" />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => deleteTimer(t)} style={s.iconBtn}>
                <Ionicons name="trash-outline" size={22} color="#bbb" />
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>
      )}

      <View style={s.tabBar}>
        {([['home', 'home', 'Home'], ['alarms', 'alarm', 'Alarms'], ['timers', 'timer', 'Timers']] as const).map(
          ([key, icon, name]) => (
            <TouchableOpacity key={key} style={s.tabItem} onPress={() => setTab(key)}>
              <Ionicons name={icon} size={24} color={tab === key ? ORANGE : '#999'} />
              <Text style={{ color: tab === key ? ORANGE : '#999', fontSize: 12, marginTop: 2 }}>{name}</Text>
            </TouchableOpacity>
          )
        )}
      </View>

      <Modal visible={!!editor} transparent animationType="slide" onRequestClose={() => setEditor(null)}>
        <KeyboardAvoidingView style={s.overlay} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <View style={s.sheet}>
            <ScrollView keyboardShouldPersistTaps="handled">
              {editor && editor.mode === 'voice' && (
                <View style={{ marginBottom: 14 }}>
                  <View style={s.voiceRow}>
                    <View style={s.miniMic}>
                      <Ionicons name="mic" size={22} color="#fff" />
                    </View>
                    <TextInput
                      style={s.cmdInput}
                      value={cmd}
                      onChangeText={onCmd}
                      placeholder='Try "Wake me at 6:30 AM on weekdays with math"'
                      placeholderTextColor="#777"
                      autoFocus
                      multiline
                    />
                  </View>
                  <Text style={s.hint}>
                    Tip: tap the 🎤 on your keyboard and speak. Say “timer 5 minutes” for a timer.
                  </Text>
                  {pc && pc.kind === null && cmd.trim() !== '' && (
                    <Text style={s.hint}>
                      Not understood yet. Try “Wake me at 6 AM” or “Timer 2 minutes 30 seconds”.
                    </Text>
                  )}
                </View>
              )}

              {isTimerCmd ? (
                <View style={s.box}>
                  <Text style={s.boxLabel}>Timer</Text>
                  <Text style={s.bigTime}>{fmtDur(pc.total)}</Text>
                  {!!pc.label && <Text style={s.cardSub}>{pc.label}</Text>}
                </View>
              ) : (
                <View style={s.box}>
                  <Text style={s.boxLabel}>Alarm time</Text>
                  <View style={s.timeRow}>
                    <TextInput
                      style={s.tInput}
                      value={hStr}
                      onChangeText={onHour}
                      onBlur={() => setHStr(String(hour % 12 || 12))}
                      keyboardType="number-pad"
                      maxLength={2}
                      selectTextOnFocus
                    />
                    <Text style={s.colon}>:</Text>
                    <TextInput
                      style={s.tInput}
                      value={mStr}
                      onChangeText={onMinute}
                      onBlur={() => setMStr(String(minute).padStart(2, '0'))}
                      keyboardType="number-pad"
                      maxLength={2}
                      selectTextOnFocus
                    />
                    <View style={{ marginLeft: 12 }}>
                      <TouchableOpacity style={[s.apBtn, !isPM && s.apOn]} onPress={() => setAmPm(false)}>
                        <Text style={s.apText}>AM</Text>
                      </TouchableOpacity>
                      <TouchableOpacity style={[s.apBtn, isPM && s.apOn]} onPress={() => setAmPm(true)}>
                        <Text style={s.apText}>PM</Text>
                      </TouchableOpacity>
                    </View>
                  </View>

                  <Text style={[s.boxLabel, { marginTop: 14 }]}>Label</Text>
                  <TextInput style={s.labelInput} value={label} onChangeText={setLabel} placeholderTextColor="#888" />

                  <Text style={[s.boxLabel, { marginTop: 14 }]}>Repeat</Text>
                  <View style={s.daysRow}>
                    {DAY_ORDER.map(i => (
                      <TouchableOpacity
                        key={i}
                        style={[s.dayChip, days[i] && { backgroundColor: ORANGE }]}
                        onPress={() => setDays(days.map((v, idx) => (idx === i ? !v : v)))}
                      >
                        <Text style={{ color: '#fff', fontWeight: '600' }}>{DAY_LETTERS[i]}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>

                  <Text style={[s.boxLabel, { marginTop: 14 }]}>Mission to stop the alarm</Text>
                  <View style={s.chipsRow}>
                    {(['None', 'Phrase', 'Math'] as Mission[]).map(m => (
                      <TouchableOpacity
                        key={m}
                        style={[s.missionChip, mission === m && { backgroundColor: ORANGE, borderColor: ORANGE }]}
                        onPress={() => setMission(m)}
                      >
                        <Text style={{ color: '#fff' }}>{m}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>

                  <Text style={[s.boxLabel, { marginTop: 14 }]}>Sound</Text>
                  <View style={s.chipsRow}>
                    <TouchableOpacity
                      style={[s.missionChip, sound === 'default' && { backgroundColor: ORANGE, borderColor: ORANGE }]}
                      onPress={() => setSound('default')}
                    >
                      <Text style={{ color: '#fff' }}>Default</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[s.missionChip, sound === 'vibrate' && { backgroundColor: ORANGE, borderColor: ORANGE }]}
                      onPress={() => setSound('vibrate')}
                    >
                      <Text style={{ color: '#fff' }}>Vibrate only</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[s.missionChip, sound === 'custom' && { backgroundColor: ORANGE, borderColor: ORANGE }]}
                      onPress={pickAudio}
                    >
                      <Text style={{ color: '#fff' }}>My audio…</Text>
                    </TouchableOpacity>
                  </View>
                  {sound === 'custom' && !!soundName && <Text style={s.hint}>♪ {soundName}</Text>}
                </View>
              )}

              <TouchableOpacity style={s.primaryBtn} onPress={accept}>
                <Text style={s.primaryText}>
                  {isTimerCmd ? '✓  Start timer' : editor && editor.id ? '✓  Save' : '✓  Accept'}
                </Text>
              </TouchableOpacity>
              {editor && editor.id && (
                <TouchableOpacity style={s.outlineBtn} onPress={deleteAlarm}>
                  <Text style={{ color: '#ff6b6b', fontSize: 16 }}>Delete alarm</Text>
                </TouchableOpacity>
              )}
              <TouchableOpacity style={s.outlineBtn} onPress={() => setEditor(null)}>
                <Text style={{ color: '#fff', fontSize: 16 }}>Cancel</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B0B0D', paddingTop: 60, paddingHorizontal: 20 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  title: { color: '#fff', fontSize: 26, fontWeight: '600' },
  clock: { color: '#fff', fontSize: 110, fontWeight: '200', textAlign: 'center', marginTop: 10 },
  pill: {
    flexDirection: 'row',
    alignSelf: 'center',
    alignItems: 'center',
    backgroundColor: '#2A1F1B',
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderRadius: 30,
  },
  pillText: { color: '#fff', fontSize: 17, marginLeft: 8 },
  quote: { color: '#ddd', fontSize: 17, textAlign: 'center', marginVertical: 22, paddingHorizontal: 10 },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  section: { color: '#bbb', fontSize: 17 },
  seeAll: { color: ORANGE, fontSize: 16 },
  card: {
    backgroundColor: '#17171A',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
  },
  cardTime: { color: '#fff', fontSize: 28, fontWeight: '500' },
  cardSub: { color: '#999', fontSize: 14, marginTop: 2 },
  testBtn: {
    borderColor: ORANGE,
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginHorizontal: 8,
  },
  testText: { color: ORANGE, fontWeight: 'bold', fontSize: 12 },
  iconBtn: { padding: 8 },
  mic: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: ORANGE,
    justifyContent: 'center',
    alignItems: 'center',
  },
  micHint: { color: '#aaa', marginTop: 12 },
  manualBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    borderColor: ORANGE,
    borderWidth: 1,
    borderRadius: 24,
    paddingHorizontal: 18,
    paddingVertical: 10,
    marginTop: 16,
  },
  manualText: { color: ORANGE, fontWeight: '600', marginLeft: 6, fontSize: 15 },
  tabBar: { flexDirection: 'row', borderTopColor: '#222', borderTopWidth: 1, paddingVertical: 10, marginHorizontal: -20 },
  tabItem: { flex: 1, alignItems: 'center' },
  overlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.6)' },
  sheet: {
    backgroundColor: '#121214',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    padding: 20,
    maxHeight: '92%',
  },
  voiceRow: { flexDirection: 'row', alignItems: 'center' },
  miniMic: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#5A2A20',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  cmdInput: { flex: 1, color: '#fff', fontSize: 17, backgroundColor: '#1C1C1F', borderRadius: 12, padding: 12 },
  hint: { color: '#888', fontSize: 13, marginTop: 8 },
  box: { backgroundColor: '#1A1A1D', borderRadius: 18, padding: 16, marginBottom: 16 },
  boxLabel: { color: '#aaa', fontSize: 14 },
  bigTime: { color: '#fff', fontSize: 44, fontWeight: '300' },
  timeRow: { flexDirection: 'row', alignItems: 'center', marginTop: 6 },
  tInput: {
    backgroundColor: '#242428',
    color: '#fff',
    fontSize: 44,
    width: 90,
    textAlign: 'center',
    borderRadius: 14,
    paddingVertical: 6,
  },
  colon: { color: '#fff', fontSize: 44, marginHorizontal: 6 },
  apBtn: {
    borderColor: '#444',
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 8,
    marginVertical: 3,
    alignItems: 'center',
  },
  apOn: { backgroundColor: ORANGE, borderColor: ORANGE },
  apText: { color: '#fff', fontWeight: '600' },
  labelInput: { color: '#fff', fontSize: 18, paddingVertical: 4 },
  daysRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 },
  dayChip: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#2A2A2E',
    justifyContent: 'center',
    alignItems: 'center',
  },
  chipsRow: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 8 },
  missionChip: {
    borderColor: '#444',
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 8,
    marginBottom: 8,
  },
  timerInputs: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  timeBox: {
    backgroundColor: '#242428',
    color: '#fff',
    fontSize: 40,
    width: 100,
    textAlign: 'center',
    borderRadius: 14,
    paddingVertical: 8,
  },
  timeUnit: { color: '#aaa', fontSize: 16, marginHorizontal: 8 },
  primaryBtn: { backgroundColor: ORANGE, padding: 16, borderRadius: 30, alignItems: 'center' },
  primaryText: { color: '#fff', fontWeight: 'bold', fontSize: 17 },
  outlineBtn: {
    borderColor: '#555',
    borderWidth: 1,
    padding: 15,
    borderRadius: 30,
    alignItems: 'center',
    marginTop: 12,
    marginBottom: 4,
  },
  ringContainer: { flex: 1, backgroundColor: '#0B0B0D', padding: 24, justifyContent: 'center' },
  ringTime: { color: '#fff', fontSize: 52, fontWeight: 'bold', textAlign: 'center' },
  ringTitle: { color: ORANGE, fontSize: 26, fontWeight: 'bold', textAlign: 'center', marginBottom: 30 },
  ringHint: { color: '#aaa', fontSize: 16, textAlign: 'center' },
  phrase: { color: '#fff', fontSize: 24, fontWeight: 'bold', textAlign: 'center', marginVertical: 16 },
  input2: {
    backgroundColor: '#1C1C1F',
    color: '#fff',
    padding: 14,
    borderRadius: 12,
    fontSize: 18,
    marginBottom: 20,
  },
});