const { withAndroidManifest } = require('expo/config-plugins');

// Lets the app screen show over the lock screen and turn the screen on when an alarm rings.
module.exports = function withAlarmActivity(config) {
  return withAndroidManifest(config, (cfg) => {
    const app = cfg.modResults.manifest.application[0];
    const main = (app.activity || []).find((a) => a.$['android:name'] === '.MainActivity');
    if (main) {
      main.$['android:showWhenLocked'] = 'true';
      main.$['android:turnScreenOn'] = 'true';
    }
    return cfg;
  });
};
