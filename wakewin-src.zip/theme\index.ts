import { Platform, TextStyle } from 'react-native';

export const colors = {
  background: '#0B0B0D',
  card: '#17171A',
  cardElevated: '#1E1E22',
  text: '#FFFFFF',
  muted: '#9A9AA0',
  accent: '#FF5A26',
  accentDim: '#FF5A2633',
  success: '#3DDC97',
  danger: '#FF4D4D',
  border: '#2A2A30',
  overlay: 'rgba(0,0,0,0.72)',
  disabled: '#3A3A40',
} as const;

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  xxxl: 48,
} as const;

export const radius = {
  sm: 10,
  md: 16,
  lg: 24,
  pill: 999,
} as const;

const thinClock: TextStyle = {
  fontFamily: Platform.select({
    android: 'sans-serif-thin',
    ios: 'HelveticaNeue-UltraLight',
    default: 'sans-serif-thin',
  }),
  fontWeight: '200',
  color: colors.text,
  letterSpacing: -2,
};

export const typography = {
  clock: {
    ...thinClock,
    fontSize: 92,
    lineHeight: 100,
  } satisfies TextStyle,
  clockSm: {
    ...thinClock,
    fontSize: 56,
    lineHeight: 64,
  } satisfies TextStyle,
  title: {
    fontSize: 22,
    fontWeight: '600',
    color: colors.text,
  } satisfies TextStyle,
  body: {
    fontSize: 16,
    fontWeight: '400',
    color: colors.text,
  } satisfies TextStyle,
  muted: {
    fontSize: 14,
    fontWeight: '400',
    color: colors.muted,
  } satisfies TextStyle,
  caption: {
    fontSize: 12,
    fontWeight: '500',
    color: colors.muted,
    letterSpacing: 0.4,
  } satisfies TextStyle,
  button: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.text,
  } satisfies TextStyle,
};

export const theme = { colors, spacing, radius, typography };
export type Theme = typeof theme;
