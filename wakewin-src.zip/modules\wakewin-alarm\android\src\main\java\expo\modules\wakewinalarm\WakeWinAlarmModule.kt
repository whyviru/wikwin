package expo.modules.wakewinalarm

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import expo.modules.kotlin.exception.Exceptions
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class WakeWinAlarmModule : Module() {
  private val ctx: Context
    get() = appContext.reactContext ?: throw Exceptions.ReactContextLost()

  private fun open(i: Intent) {
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try { ctx.startActivity(i) } catch (e: Exception) {}
  }

  override fun definition() = ModuleDefinition {
    Name("WakeWinAlarm")

    Function("syncAlarms") { json: String ->
      Store.saveAlarms(ctx, json)
      Scheduler.scheduleAll(ctx)
    }

    Function("scheduleTimer") { id: String, endAt: Double, label: String ->
      Scheduler.scheduleTimer(ctx, id, endAt.toLong(), label)
    }

    Function("cancelTimer") { id: String ->
      Scheduler.cancelTimer(ctx, id)
    }

    Function("getActiveAlarm") {
      Store.active(ctx)
    }

    Function("stopAlarm") {
      Store.clearActive(ctx)
      ctx.stopService(Intent(ctx, AlarmService::class.java))
    }

    Function("canUseFullScreen") {
      if (Build.VERSION.SDK_INT >= 34) {
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).canUseFullScreenIntent()
      } else true
    }

    Function("openFullScreenSettings") {
      val pkg = Uri.parse("package:" + ctx.packageName)
      if (Build.VERSION.SDK_INT >= 34) open(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkg))
      else open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg))
    }

    Function("isIgnoringBattery") {
      (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
    }

    Function("openBatterySettings") {
      open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }
  }
}
