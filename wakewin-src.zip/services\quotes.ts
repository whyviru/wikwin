const QUOTES = [
  'Discipline is choosing between what you want now and what you want most.',
  'Win the morning, win the day.',
  'You do not rise to the occasion. You fall to your training.',
  'The alarm is a promise you made to tomorrow-you.',
  'Show up. Especially when it is hard.',
  'Small wins stack into a life you are proud of.',
  'Your future is built in the minutes after the alarm.',
  'Be the person who gets up.',
  'Comfort is the enemy of the morning.',
  'Make the bed. Make the day.',
];

export function quoteForDate(date = new Date()): string {
  const start = new Date(date.getFullYear(), 0, 0);
  const day = Math.floor((date.getTime() - start.getTime()) / 86_400_000);
  return QUOTES[day % QUOTES.length];
}

export function randomQuote(): string {
  return QUOTES[Math.floor(Math.random() * QUOTES.length)];
}
