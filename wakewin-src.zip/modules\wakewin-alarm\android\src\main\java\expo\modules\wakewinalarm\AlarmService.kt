package expo.modules.wakewinalarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator

class AlarmService : Service() {
  private var player: MediaPlayer? = null
  private var wake: PowerManager.WakeLock? = null
  private var vibrator: Vibrator? = null

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    val kind = intent?.getStringExtra("kind") ?: "alarm"
    val id = intent?.getStringExtra("id") ?: ""

    var label = "Alarm"
    var sound = "default"
    var uri: String? = null
    if (kind == "alarm") {
      Store.findAlarm(this, id)?.let {
        label = it.optString("label", "Alarm")
        sound = it.optString("sound", "default")
        uri = it.optString("soundUri", "").ifEmpty { null }
      }
    } else {
      label = Store.timers(this).optJSONObject(id)?.optString("label", "") ?: ""
      if (label.isEmpty()) label = "Timer"
    }

    val notification = buildNotification(label, if (kind == "timer") "Time's up! Tap to stop" else "Tap to stop the alarm")
    if (Build.VERSION.SDK_INT >= 29) {
      startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
    } else {
      startForeground(NOTIF_ID, notification)
    }

    val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
    wake?.let { if (it.isHeld) it.release() }
    wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wakewin:alarm").apply { acquire(30 * 60 * 1000L) }

    stopSound()
    if (sound != "vibrate") {
      player = makePlayer(if (sound == "custom") uri else null)
      try { player?.start() } catch (e: Exception) {}
    }
    startVibration()
    return START_NOT_STICKY
  }

  private fun makePlayer(customUri: String?): MediaPlayer? {
    fun base() = MediaPlayer().apply {
      setAudioAttributes(
        AudioAttributes.Builder()
          .setUsage(AudioAttributes.USAGE_ALARM)
          .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
          .build()
      )
      isLooping = true
    }
    if (!customUri.isNullOrEmpty()) {
      try {
        return base().apply {
          setDataSource(this@AlarmService, Uri.parse(customUri))
          prepare()
        }
      } catch (e: Exception) { /* fall back to the built-in sound */ }
    }
    try {
      val resId = resources.getIdentifier("alarm", "raw", packageName)
      val afd = resources.openRawResourceFd(resId)
      return base().apply {
        setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
        afd.close()
        prepare()
      }
    } catch (e: Exception) {
      return null
    }
  }

  @Suppress("DEPRECATION")
  private fun startVibration() {
    try {
      val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
      vibrator = v
      val pattern = longArrayOf(0, 800, 400)
      if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pattern, 0))
      else v.vibrate(pattern, 0)
    } catch (e: Exception) {}
  }

  private fun stopSound() {
    try { player?.stop() } catch (e: Exception) {}
    try { player?.release() } catch (e: Exception) {}
    player = null
  }

  private fun buildNotification(title: String, text: String): Notification {
    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26) {
      val ch = NotificationChannel(CHANNEL, "Alarms", NotificationManager.IMPORTANCE_HIGH).apply {
        setSound(null, null)
        enableVibration(false)
        lockscreenVisibility = Notification.VISIBILITY_PUBLIC
      }
      nm.createNotificationChannel(ch)
    }
    val launch = packageManager.getLaunchIntentForPackage(packageName)?.apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    }
    val pi = PendingIntent.getActivity(
      this, 7, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    @Suppress("DEPRECATION")
    val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
    b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
      .setContentTitle(title)
      .setContentText(text)
      .setCategory(Notification.CATEGORY_ALARM)
      .setOngoing(true)
      .setVisibility(Notification.VISIBILITY_PUBLIC)
      .setContentIntent(pi)
      .setFullScreenIntent(pi, true)
    return b.build()
  }

  override fun onDestroy() {
    stopSound()
    try { vibrator?.cancel() } catch (e: Exception) {}
    wake?.let { if (it.isHeld) it.release() }
    super.onDestroy()
  }

  companion object {
    const val CHANNEL = "wakewin_alarm"
    const val NOTIF_ID = 4242
  }
}
