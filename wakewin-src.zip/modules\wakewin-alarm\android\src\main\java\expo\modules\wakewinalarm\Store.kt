package expo.modules.wakewinalarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Store {
  private fun p(c: Context) = c.getSharedPreferences("wakewin_alarm", Context.MODE_PRIVATE)

  // ---- alarms (JSON array sent from the app) ----
  fun saveAlarms(c: Context, json: String) {
    p(c).edit().putString("alarms", json).apply()
  }

  fun alarms(c: Context): JSONArray =
    try { JSONArray(p(c).getString("alarms", "[]")) } catch (e: Exception) { JSONArray() }

  fun findAlarm(c: Context, id: String): JSONObject? {
    val a = alarms(c)
    for (i in 0 until a.length()) {
      val o = a.getJSONObject(i)
      if (o.optString("id") == id) return o
    }
    return null
  }

  fun setAlarmOff(c: Context, id: String) {
    val a = alarms(c)
    for (i in 0 until a.length()) {
      val o = a.getJSONObject(i)
      if (o.optString("id") == id) o.put("on", false)
    }
    saveAlarms(c, a.toString())
  }

  fun scheduledIds(c: Context): Set<String> =
    p(c).getStringSet("scheduled", emptySet()) ?: emptySet()

  fun saveScheduledIds(c: Context, ids: Set<String>) {
    p(c).edit().putStringSet("scheduled", HashSet(ids)).apply()
  }

  // ---- timers ----
  fun timers(c: Context): JSONObject =
    try { JSONObject(p(c).getString("timers", "{}")) } catch (e: Exception) { JSONObject() }

  fun putTimer(c: Context, id: String, endAt: Long, label: String) {
    val t = timers(c)
    t.put(id, JSONObject().put("endAt", endAt).put("label", label))
    p(c).edit().putString("timers", t.toString()).apply()
  }

  fun removeTimer(c: Context, id: String) {
    val t = timers(c)
    t.remove(id)
    p(c).edit().putString("timers", t.toString()).apply()
  }

  // ---- the alarm that is ringing right now ----
  fun setActive(c: Context, kind: String, id: String) {
    p(c).edit()
      .putString("active_kind", kind)
      .putString("active_id", id)
      .putLong("active_at", System.currentTimeMillis())
      .apply()
  }

  fun clearActive(c: Context) {
    p(c).edit().remove("active_kind").remove("active_id").remove("active_at").apply()
  }

  fun active(c: Context): Map<String, String>? {
    val id = p(c).getString("active_id", null) ?: return null
    val kind = p(c).getString("active_kind", "alarm") ?: "alarm"
    val at = p(c).getLong("active_at", 0L)
    if (System.currentTimeMillis() - at > 30 * 60 * 1000) {
      clearActive(c)
      return null
    }
    return mapOf("kind" to kind, "id" to id)
  }
}
