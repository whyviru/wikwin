import type { Alarm } from '@/types/models';

export function pad2(n: number): string {
  return n.toString().padStart(2, '0');
}

export function formatTime(hour: number, minute: number): { time: string; period: 'AM' | 'PM' } {
  const period: 'AM' | 'PM' = hour >= 12 ? 'PM' : 'AM';
  const h = hour % 12 || 12;
  return { time: `${pad2(h)}:${pad2(minute)}`, period };
}

export function formatDuration(ms: number): string {
  if (ms <= 0) return '0m';
  const totalMin = Math.floor(ms / 60_000);
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  if (h <= 0) return `${m}m`;
  return `${h}h ${m}m`;
}

/** Next fire time after `from`. One-shot alarms use the next clock time; repeating uses weekdays. */
export function getNextAlarmDate(alarm: Alarm, from = new Date()): Date | null {
  if (!alarm.enabled) return null;
  const days = alarm.repeatDays;

  for (let add = 0; add <= 8; add++) {
    const candidate = new Date(from);
    candidate.setSeconds(0, 0);
    candidate.setMilliseconds(0);
    candidate.setDate(from.getDate() + add);
    candidate.setHours(alarm.hour, alarm.minute, 0, 0);
    if (candidate.getTime() <= from.getTime()) continue;
    if (days.length === 0) return candidate;
    if (days.includes(candidate.getDay())) return candidate;
  }
  return null;
}

export function getSoonestAlarm(alarms: Alarm[], from = new Date()): { alarm: Alarm; at: Date } | null {
  let best: { alarm: Alarm; at: Date } | null = null;
  for (const alarm of alarms) {
    const at = getNextAlarmDate(alarm, from);
    if (!at) continue;
    if (!best || at.getTime() < best.at.getTime()) best = { alarm, at };
  }
  return best;
}

export function newId(prefix = 'id'): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export function summarizeMissions(alarm: Alarm): string {
  if (!alarm.missions.length) return 'No missions';
  return alarm.missions
    .map((m) => {
      switch (m.type) {
        case 'phrase':
          return 'Phrase';
        case 'math':
          return `Math ×${m.config.count}`;
        case 'photo':
          return `Photo · ${m.config.target}`;
        case 'shake':
          return `Shake ×${m.config.count}`;
        case 'memory':
          return `Memory ${m.config.gridSize}×${m.config.gridSize}`;
      }
    })
    .join(' · ');
}

export function repeatLabel(days: number[]): string {
  if (days.length === 0) return 'Once';
  if (days.length === 7) return 'Every day';
  const weekdays = [1, 2, 3, 4, 5];
  const weekend = [0, 6];
  const same = (a: number[], b: number[]) =>
    a.length === b.length && a.every((d) => b.includes(d));
  if (same(days, weekdays)) return 'Weekdays';
  if (same(days, weekend)) return 'Weekends';
  const names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  return [...days].sort((a, b) => a - b).map((d) => names[d]).join(' ');
}
