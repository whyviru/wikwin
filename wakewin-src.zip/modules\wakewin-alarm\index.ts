import { requireOptionalNativeModule } from 'expo';
import { Alert, PermissionsAndroid, Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Native: any = Platform.OS === 'android' ? requireOptionalNativeModule('WakeWinAlarm') : null;

export type ActiveAlarm = { kind: 'alarm' | 'timer'; id: string };

export function syncAlarms(alarms: any[]) {
  try {
    const slim = alarms.map(a => ({
      id: a.id,
      hour: a.hour,
      minute: a.minute,
      days: a.days,
      on: a.on,
      label: a.label,
      sound: a.sound,
      soundUri: a.soundUri || '',
    }));
    Native?.syncAlarms(JSON.stringify(slim));
  } catch (e) {}
}

export function scheduleTimer(id: string, endAt: number, label: string) {
  try { Native?.scheduleTimer(id, endAt, label || ''); } catch (e) {}
}

export function cancelTimer(id: string) {
  try { Native?.cancelTimer(id); } catch (e) {}
}

export function getActiveAlarm(): ActiveAlarm | null {
  try { return Native?.getActiveAlarm() ?? null; } catch (e) { return null; }
}

export function stopAlarm() {
  try { Native?.stopAlarm(); } catch (e) {}
}

const ask = (title: string, msg: string, ok: string) =>
  new Promise<boolean>(res =>
    Alert.alert(title, msg, [
      { text: 'Later', style: 'cancel', onPress: () => res(false) },
      { text: ok, onPress: () => res(true) },
    ], { cancelable: false })
  );

/** First launch: ask for the permissions a reliable alarm needs. */
export async function runSetupOnce() {
  if (!Native) return;
  try {
    if (await AsyncStorage.getItem('wakewin_setup_v1')) return;
    await AsyncStorage.setItem('wakewin_setup_v1', '1');

    if (Number(Platform.Version) >= 33) {
      await PermissionsAndroid.request('android.permission.POST_NOTIFICATIONS' as any);
    }
    if (!Native.canUseFullScreen()) {
      if (await ask('Show alarm over lock screen', 'Allow "full-screen notifications" so WakeWin can open when your alarm rings.', 'Open settings')) {
        Native.openFullScreenSettings();
        return;
      }
    }
    if (!Native.isIgnoringBattery()) {
      if (await ask('Keep alarms reliable', 'Turn off battery optimization for WakeWin so your phone never blocks the alarm.', 'Open settings')) {
        Native.openBatterySettings();
      }
    }
  } catch (e) {}
}
