package expo.modules.wakewinalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    val kind = intent.getStringExtra("kind") ?: "alarm"
    val id = intent.getStringExtra("id") ?: return

    Store.setActive(context, kind, id)

    val svc = Intent(context, AlarmService::class.java).putExtra("kind", kind).putExtra("id", id)
    if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(svc) else context.startService(svc)

    if (kind == "alarm") Scheduler.afterFire(context, id) else Store.removeTimer(context, id)
  }
}

class BootReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    Scheduler.restoreAfterBoot(context)
  }
}
