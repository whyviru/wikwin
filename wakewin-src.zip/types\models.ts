export type MissionType = 'phrase' | 'math' | 'photo' | 'shake' | 'memory';

export type MathDifficulty = 'easy' | 'medium' | 'hard';

export type PhraseConfig = { text: string };
export type MathConfig = { difficulty: MathDifficulty; count: number };
export type PhotoConfig = { target: string };
export type ShakeConfig = { count: number };
export type MemoryConfig = { gridSize: number };

export type Mission =
  | { type: 'phrase'; config: PhraseConfig }
  | { type: 'math'; config: MathConfig }
  | { type: 'photo'; config: PhotoConfig }
  | { type: 'shake'; config: ShakeConfig }
  | { type: 'memory'; config: MemoryConfig };

export type Alarm = {
  id: string;
  hour: number;
  minute: number;
  label: string;
  /** JS getDay() values: 0 Sunday … 6 Saturday. Empty = one-shot. */
  repeatDays: number[];
  enabled: boolean;
  missions: Mission[];
  snoozeMax: number;
  risingVolume: boolean;
  soundId: string;
};

export type TimerItem = {
  id: string;
  label: string;
  /** Epoch ms when the timer should fire. */
  scheduledAt: number;
  enabled: boolean;
};

export type Settings = {
  defaultSoundId: string;
  onboardingComplete: boolean;
};

export const PREMIUM_MISSIONS: MissionType[] = ['math', 'photo', 'shake', 'memory'];

export const PHOTO_TARGETS = ['stairs', 'door', 'fan', 'water tank'] as const;

export const DEFAULT_PHRASE = 'I will work and I will win';

export const DAY_LABELS = ['S', 'M', 'T', 'W', 'T', 'F', 'S'] as const;
export const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] as const;
